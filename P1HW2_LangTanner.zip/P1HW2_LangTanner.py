# This program calculates and displays travel expenses
# 16-FEB-2023
# CTI-110P1HW2-Travel Expense
# Tanner Lang

print("This program calculates and displays travel expenses")
print()
budget = float(input("Enter the budget: "))
print()
name = (input("Enter your travel destination: "))
print()
gas = float(input("How much do you think you will spend on gas:"))
print()
Accomodation = float(input("Approximately, how much will you need for Accomodationa/Hotel?: "))
print()
food = float(input("How much do you think you will need for food: "))
print()
print("-"*12,"Travel Expenses",12*"-")
print("Location:" ,name)
print()
print("initial Budget:" ,budget)
print()
print("Fuel:" ,gas)
print("Accomodation:" ,Accomodation)
print()
balance = budget - gas - food - Accomodation
#print("remaining Balance:" ,Balance)
print("Remaning Balance:" ,format(balance,',.0f'))
